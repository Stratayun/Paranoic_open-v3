plugins {
    kotlin("multiplatform") version "2.2.21" apply false
    kotlin("plugin.compose") version "2.2.21" apply false
    id("org.jetbrains.compose") version "1.9.1" apply false
    id("com.android.application") version "8.11.1" apply false
}

